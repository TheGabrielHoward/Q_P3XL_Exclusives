# [QPP6] GSI Pixel 3 XL Exclusives

Pixel 3 XL exclusive apps and files for GSIs to enable Pixel 3 exclusive features.

### Features:
With this module you will get:
- Now Playing (Maybe broken)
- Battery Stats on Quick Settings
- AR Core
- Google Maps AR
- PlayGround
- New Google Sans Font
- Driving mode
- Pixel Tips
- Connectivity Health Services
- Pixel Visual Core
- Pixel Stand
- Smart Compose (Gmail)
- Merged p3xl build.prop
- More

### Changelog

**v4**
- Merged QPP6 Pixel 3XL build.prop
- Updated Ambient Sense Prebuilt
- Updated permissions
- Updated Google Sans Font
- Fixed ARCore
- Added QPP6 Bootanimation
- Added overlays from QPP6
- Fixed Safetynet